import requests
import streamlit as st

API = "http://127.0.0.1:8000/api/v1"
st.set_page_config(page_title="Фильмы", layout="wide")


@st.cache_data(ttl=300)
def api_get(path, params=None):
    try:
        response = requests.get(API + path, params=params, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.RequestException:
        st.error("API недоступен. Запусти: uvicorn app.api:app --reload")
        st.stop()


def show_recommendations(data):
    if data["fallback"]:
        st.info("Недостаточно персональных данных, показаны популярные фильмы.")
    labels = {"popular": "Рейтинг", "content": "Сходство", "user": "Прогноз", "item": "Прогноз"}
    score_label = labels[data["algorithm"]]
    rows = [
        {
            "Фильм": movie["title"],
            "Жанры": movie["genres"].replace("|", ", "),
            "Средняя оценка": movie["average_rating"],
            "Количество оценок": movie["rating_count"],
            score_label: movie["score"],
        }
        for movie in data["items"]
    ]
    st.dataframe(rows, use_container_width=True, hide_index=True)


def show_help():
    st.markdown(
        """
## Справка
Данные: **MovieLens latest-small**, локальные CSV-файлы. БД и сохранение оценок не используются.

### Алгоритмы
- **Популярные** — взвешенный рейтинг фильмов.
- **По пользователям** — рекомендации похожих зрителей.
- **По фильмам** — рекомендации на основе похожих фильмов.
- **По содержанию** — сравнение названий и жанров через TF-IDF.

### Команды API
- `GET /api/v1/users` — пользователи.
- `GET /api/v1/movies?query=Matrix&limit=100` — поиск фильмов.
- `GET /api/v1/movies/popular?limit=10` — популярные фильмы.
- `GET /api/v1/recommendations/content/1?limit=10` — похожие по содержанию.
- `GET /api/v1/recommendations/collaborative/1?method=user&limit=10` — персональные; `method=user` или `item`.

### Запуск
```bash
uvicorn app.api:app --reload
streamlit run app/Фильмы.py
```
[Документация Swagger](http://127.0.0.1:8000/docs)
"""
    )


st.title("Фильмы")
section = st.sidebar.radio(
    "Раздел",
    ["Популярные фильмы", "Персональные рекомендации", "Похожие по содержанию", "Справка"],
)

if section == "Популярные фильмы":
    st.header("Топ-10 популярных фильмов")
    show_recommendations(api_get("/movies/popular"))
elif section == "Персональные рекомендации":
    st.header("Персональные рекомендации")
    users = api_get("/users")
    names = {u["id"]: f"{u['name']} ({u['rating_count']} оценок)" for u in users}
    user_id = st.selectbox("Пользователь", names.keys(), format_func=names.get)
    method = st.radio(
        "Метод", ["user", "item"],
        format_func=lambda m: "По пользователям" if m == "user" else "По фильмам",
        horizontal=True,
    )
    show_recommendations(api_get(f"/recommendations/collaborative/{user_id}", {"method": method}))
elif section == "Похожие по содержанию":
    st.header("Похожие по содержанию")
    query = st.text_input("Поиск фильма", "Toy Story")
    movies = api_get("/movies", {"query": query})
    if movies:
        names = {movie["id"]: movie["title"] for movie in movies}
        movie_id = st.selectbox("Фильм", names.keys(), format_func=names.get)
        show_recommendations(api_get(f"/recommendations/content/{movie_id}"))
    else:
        st.warning("Ничего не найдено.")
else:
    show_help()
