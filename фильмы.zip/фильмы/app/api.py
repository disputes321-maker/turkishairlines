from typing import Literal

from fastapi import FastAPI, HTTPException, Query

from app import recommender

app = FastAPI(title="API рекомендательной системы фильмов")


@app.get("/")
def root():
    return {"docs": "/docs", "health": "/api/v1/health"}


@app.get("/api/v1/health")
def health():
    return {"status": "ok"}


@app.get("/api/v1/users")
def users():
    return recommender.USERS


@app.get("/api/v1/movies")
def movies(query: str = "", limit: int = Query(100, ge=1, le=100)):
    found = recommender.MOVIES[
        recommender.MOVIES["title"].str.contains(query, case=False, regex=False)
    ].head(limit)
    return [
        {"id": int(row.id), "title": row.title, "genres": row.genres}
        for row in found.itertuples()
    ]


@app.get("/api/v1/movies/popular")
def popular_movies(limit: int = Query(10, ge=1, le=50)):
    return {
        "algorithm": "popular",
        "fallback": False,
        "items": recommender.popular(limit),
    }


@app.get("/api/v1/recommendations/content/{movie_id}")
def content_recommendations(movie_id: int, limit: int = Query(10, ge=1, le=50)):
    if movie_id not in recommender.MOVIE_INDEX:
        raise HTTPException(status_code=404, detail="Фильм не найден")
    return {
        "algorithm": "content",
        "fallback": False,
        "items": recommender.content(movie_id, limit),
    }


@app.get("/api/v1/recommendations/collaborative/{user_id}")
def personal_recommendations(
    user_id: int,
    method: Literal["user", "item"] = "user",
    limit: int = Query(10, ge=1, le=50),
):
    if user_id not in recommender.USER_IDS:
        raise HTTPException(status_code=404, detail="Пользователь не найден")
    items, fallback = recommender.collaborative(user_id, method, limit)
    return {"algorithm": method, "fallback": fallback, "items": items}
