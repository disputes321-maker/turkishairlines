from fastapi.testclient import TestClient

from app.api import app
from app.recommender import MOVIES, RATINGS, USERS

client = TestClient(app)


def test_movielens_dataset_loaded():
    assert len(MOVIES) > 9000
    assert len(RATINGS) == 100836
    assert len(USERS) == 611


def test_health():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_popular_returns_ten_movies():
    response = client.get("/api/v1/movies/popular")
    assert response.status_code == 200
    data = response.json()
    assert data["algorithm"] == "popular"
    assert len(data["items"]) == 10
    assert len({movie["movie_id"] for movie in data["items"]}) == 10


def test_content_recommendations_exclude_source_movie():
    response = client.get("/api/v1/recommendations/content/1")
    assert response.status_code == 200
    items = response.json()["items"]
    assert len(items) == 10
    assert all(movie["movie_id"] != 1 for movie in items)
    assert all(0 <= movie["score"] <= 1 for movie in items)


def test_user_based_recommendations_exclude_rated_movies():
    user_id = 1
    response = client.get(
        f"/api/v1/recommendations/collaborative/{user_id}",
        params={"method": "user"},
    )
    assert response.status_code == 200
    items = response.json()["items"]
    rated = set(RATINGS.loc[RATINGS["user_id"] == user_id, "movie_id"])
    assert len(items) == 10
    assert all(movie["movie_id"] not in rated for movie in items)


def test_item_based_recommendations():
    response = client.get(
        "/api/v1/recommendations/collaborative/1", params={"method": "item"}
    )
    assert response.status_code == 200
    assert response.json()["algorithm"] == "item"
    items = response.json()["items"]
    assert len(items) == 10
    assert all(movie["rating_count"] >= 5 for movie in items)
    assert len({movie["score"] for movie in items}) > 1


def test_cold_start_user_gets_popular_fallback():
    user_id = next(user["id"] for user in USERS if user["rating_count"] == 0)
    response = client.get(f"/api/v1/recommendations/collaborative/{user_id}")
    assert response.status_code == 200
    data = response.json()
    assert data["fallback"] is True
    assert len(data["items"]) == 10


def test_unknown_entities_and_invalid_parameters():
    assert client.get("/api/v1/recommendations/content/999999").status_code == 404
    assert client.get("/api/v1/recommendations/collaborative/999999").status_code == 404
    assert client.get("/api/v1/movies/popular?limit=0").status_code == 422
    assert (
        client.get("/api/v1/recommendations/collaborative/1?method=unknown").status_code
        == 422
    )


def test_movie_search():
    response = client.get("/api/v1/movies", params={"query": "matrix"})
    assert response.status_code == 200
    assert len(response.json()) >= 1
    assert all("matrix" in movie["title"].lower() for movie in response.json())
