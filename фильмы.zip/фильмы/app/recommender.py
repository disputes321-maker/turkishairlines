from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DATA = Path(__file__).resolve().parent.parent / "data"
MOVIES = pd.read_csv(DATA / "movies.csv").rename(columns={"movieId": "id"})
RATINGS = pd.read_csv(DATA / "ratings.csv").rename(
    columns={"userId": "user_id", "movieId": "movie_id", "rating": "score"}
)

stats = RATINGS.groupby("movie_id")["score"].agg(["mean", "count"])
stats.columns = ["average_rating", "rating_count"]
MOVIES = MOVIES.merge(stats, left_on="id", right_index=True, how="left")
MOVIES["average_rating"] = MOVIES["average_rating"].fillna(0)
MOVIES["rating_count"] = MOVIES["rating_count"].fillna(0).astype(int)

USER_IDS = sorted(RATINGS["user_id"].unique()) + [0]
MOVIE_IDS = MOVIES["id"].tolist()
MOVIE_INDEX = {movie_id: index for index, movie_id in enumerate(MOVIE_IDS)}
USERS = [
    {
        "id": int(user_id),
        "name": f"Пользователь {user_id}",
        "rating_count": int((RATINGS["user_id"] == user_id).sum()),
    }
    for user_id in USER_IDS[:-1]
]
USERS.append({"id": 0, "name": "Новый пользователь", "rating_count": 0})

MATRIX = (
    RATINGS.pivot(index="user_id", columns="movie_id", values="score")
    .reindex(index=USER_IDS, columns=MOVIE_IDS)
    .fillna(0)
    .to_numpy()
)
counts = (MATRIX > 0).sum(axis=1)
MEANS = np.divide(
    MATRIX.sum(axis=1), counts, out=np.zeros(len(USER_IDS)), where=counts > 0
)
CENTERED = np.where(MATRIX > 0, MATRIX - MEANS[:, None], 0)
TEXTS = (MOVIES["title"] + " " + MOVIES["genres"].str.replace("|", " ", regex=False)).tolist()
VECTORS = TfidfVectorizer().fit_transform(TEXTS)

global_average = RATINGS["score"].mean()
votes = MOVIES["rating_count"].to_numpy()
POPULAR_SCORES = (
    votes / (votes + 20) * MOVIES["average_rating"].to_numpy()
    + 20 / (votes + 20) * global_average
)
POPULAR_ORDER = np.argsort(POPULAR_SCORES)[::-1]


def movie_json(index, score):
    movie = MOVIES.iloc[index]
    return {
        "movie_id": int(movie["id"]),
        "title": movie["title"],
        "genres": movie["genres"],
        "score": round(float(score), 3),
        "average_rating": round(float(movie["average_rating"]), 2),
        "rating_count": int(movie["rating_count"]),
    }


def popular(limit=10, exclude=()):
    items = []
    for index in POPULAR_ORDER:
        if MOVIE_IDS[index] not in exclude:
            items.append(movie_json(index, POPULAR_SCORES[index]))
        if len(items) == limit:
            break
    return items


def content(movie_id, limit=10):
    index = MOVIE_INDEX[movie_id]
    similarities = cosine_similarity(VECTORS[index], VECTORS)[0]
    similarities[index] = -1
    indices = np.argsort(similarities)[-limit:][::-1]
    return [movie_json(i, similarities[i]) for i in indices]


def collaborative(user_id, method, limit=10):
    user_index = USER_IDS.index(user_id)
    target = MATRIX[user_index]
    rated = target > 0
    if not rated.any():
        return popular(limit), True

    if method == "user":
        similarities = cosine_similarity(CENTERED[[user_index]], CENTERED)[0]
        similarities[user_index] = 0
        similarities[similarities < 0] = 0
        neighbors = np.argsort(similarities)[-50:]
        weights = similarities[neighbors, None] * (MATRIX[neighbors] > 0)
        numerator = (weights * MATRIX[neighbors]).sum(axis=0)
        denominator = weights.sum(axis=0)
        support = (weights > 0).sum(axis=0)
    else:
        rated_indices = np.flatnonzero(rated)
        similarities = cosine_similarity(
            CENTERED[:, rated_indices].T, CENTERED.T
        )
        deviations = target[rated_indices] - MEANS[user_index]
        numerator = deviations @ similarities
        denominator = np.abs(similarities).sum(axis=0)
        support = (np.abs(similarities) > 1e-8).sum(axis=0)

    valid = (
        (denominator > 0)
        & (support >= 3)
        & (MOVIES["rating_count"].to_numpy() >= 5)
        & ~rated
    )
    scores = np.full(len(MOVIES), -np.inf)
    if method == "user":
        scores[valid] = numerator[valid] / denominator[valid]
    else:
        scores[valid] = MEANS[user_index] + numerator[valid] / denominator[valid]
    indices = [i for i in np.argsort(scores)[::-1] if np.isfinite(scores[i])][:limit]
    items = [movie_json(i, np.clip(scores[i], 0.5, 5)) for i in indices]
    fallback = len(items) < limit
    if fallback:
        exclude = set(np.array(MOVIE_IDS)[rated]) | {m["movie_id"] for m in items}
        items += popular(limit - len(items), exclude)
    return items, fallback
